#include <Rcpp.h>
using namespace Rcpp;

#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <tuple>
#include <algorithm>
#include <climits>


class Node {

  public:
    std::string encoding;
    std::string motif;
    int span;
    int rep_count;
    int runlength;
    int index;
    std::vector<Node*> children;

  Node(std::string enc, std::string motif_pattern) : encoding(enc), motif(motif_pattern), span(0), rep_count(0), runlength(0), index(0) {}

  // Add a child node to the current node
  Node* AddChild(std::string enc, std::string motif_pattern) {
    Node* child = new Node(enc, motif_pattern);
    children.push_back(child);
    return child;
  }

  // Remove a specific child node by encoding
  void RemoveChild(std::string enc) {
    children.erase(std::remove_if(children.begin(), children.end(),
                                  [&](Node* child) { return child->encoding == enc; }), children.end());
  }

  // Recursively free memory
  ~Node() {
    for (Node* child : children) {
      delete child;
    }
  }
};

// Function to encode the motif and return relevant encoding details
std::tuple<int, std::string, std::string, int, int> encode_motif(const std::string& motif, const std::string& seq, int start, int motif_len, const std::string& motif_before, int n) {
  int count = 1;
  while (start + motif_len * (count+1) <= n && seq.substr(start + motif_len * count, motif_len) == motif) {
    count++;
  }
  std::string encoding = motif + (count > 1 ? std::to_string(count) : "");
  std::string combined_motif = motif_before + "+" + encoding;
  return {count, encoding, combined_motif, static_cast<int>(combined_motif.size()), motif_len * count};
}


// Function to iteratively build and prune the tree
void build_and_prune_tree(Node* rootNode, const std::string& seq, int start_index, int n) {
  std::queue<Node*> node_queue;
  node_queue.push(rootNode);

  int min_runlength[n+1]; // record the min runlength for each index
  std::fill(min_runlength, min_runlength+n+1, 10*n);

  Node* bestNode; //we keep a pointer to the bestNode
  bestNode = rootNode;

  while (!node_queue.empty()) {
    Node* node = node_queue.front();
    node_queue.pop();

    int i = node->index;
    if (i >= n) continue; // should not occur
    // si le current node a runlength plus grand pour index plus petit, elimine
    if ((node->index <= bestNode->index) && (node->runlength > bestNode->runlength)) { continue;}

    int rep_span[6] = {0,0,0,0,0,0};
    int rep_count[6] = {0,0,0,0,0,0};
    std::string names[6];

    for (int length = 1; length <= 6; ++length) {
      if (i + length <= n) {
        std::string motif = seq.substr(i, length);
        auto [count, encoding, combined_motif, runlength, len] = encode_motif(motif, seq, i, length, node->motif, n);

        Node* child = node->AddChild(encoding, combined_motif);
        child->span = len;
        child->rep_count = count;
        child->index = i + len;
        child->runlength = runlength;

        rep_span[length - 1] = len;
        rep_count[length - 1] = count;
        names[length - 1] = encoding;
        if (runlength < min_runlength[i+len]) {
          min_runlength[i+len]=runlength;
          //std::cout << "min_runlength["<<i+len<<"]="<<runlength<<"\n";
        }
      }
    }

  // Sort based on rep_count to retain the best (max) motif
  auto max_span_it = std::max_element(std::begin(rep_span), std::end(rep_span));
    int max_span = *max_span_it;

    if (max_span >= 6){
      // select with maximum count (smallest repeat)
      auto max_count_it = std::max_element(std::begin(rep_count), std::end(rep_count));
      int max_count = *max_count_it;
      for (int j = 0; j < 6; ++j) {
        if (rep_count[j] < max_count) {
          node->RemoveChild(names[j]);
        }
      }
    }

    // Push all remaining children to the stack for further expansion if runlength OK
    for (Node* child : node->children) {
      if ((child->index >= bestNode->index) && (child->runlength < bestNode->runlength)) {bestNode = child;}
      if (child->runlength <= min_runlength[child->index]) {
        node_queue.push(child);
        // std::cout << "keep " << child->index <<" rl " << child-> runlength <<" " << child->motif << "\n";
      } else {
        //  std::cout << "remove " << child->index <<" rl "<< child-> runlength <<" " << child->motif << "\n";
      }
    }
    //      std::cout << "index " << bestNode->index << " runlength "<< bestNode->runlength << " stack size " << node_queue.size() <<"\n";
  }
}


// [[Rcpp::export]]

std::string rle_tree_searchCPP(const std::string& seq, const std::string& first_pattern, const std::string& last_pattern) {
  int n = seq.size() - last_pattern.size();  // Maximum length of seq

  // Create the root of the tree
  Node* rootNode = new Node("rootNode", first_pattern);
  rootNode->index = first_pattern.size();  // Starting index
  rootNode->runlength = first_pattern.size();
  // Initial max_runlength is large; it will be updated with the best leaf found
  int max_runlength = -1;

  // Iteratively build the tree, pruning nodes
  build_and_prune_tree(rootNode, seq, first_pattern.size(), n);

  // Find the motif with the minimal runlength
  Node* best_leaf = nullptr;

  std::stack<Node*> node_stack;
  node_stack.push(rootNode);

  while (!node_stack.empty()) {
    Node* node = node_stack.top();
    node_stack.pop();

    if (node->children.empty() && node->index == n ) {  // It's a terminal leaf, right on the
      if (max_runlength<0) max_runlength = node->runlength;
      if (node->runlength < max_runlength) {
        max_runlength = node->runlength;
        best_leaf = node;
        //              std::cout << node->motif <<"\n";
      }
    }

    for (Node* child : node->children) {
      node_stack.push(child);
    }
  }

  std::string final_motif = best_leaf ? best_leaf->motif + "+" + last_pattern : "";

  // Clean up the tree memory
  delete rootNode;

  return final_motif;
}
